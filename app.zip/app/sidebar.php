<?php
/**
 * The sidebar.php template for our theme
 *
 * @package WordPress
 * @subpackage pc-runa
 */
?>
<aside class="r-sidebar">
	<?php dynamic_sidebar('right-sidebar');?>
</aside>