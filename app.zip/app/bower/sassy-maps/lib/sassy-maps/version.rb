module SassyMaps
  VERSION = "0.4.0"
  DATE = "2014-06-03"
end
