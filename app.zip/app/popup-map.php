<div id="yamaps" class="map-wrap el-hide">
    <script type="text/javascript" charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=j3e4gL1EIZtIesVKlOUPbx-3wAysQF1Y&lang=ru_RU&sourceType=constructor"></script>
</div>
