<div class="loader">
    <div class="loader_inner"></div>
</div>