<div id="contact_form_pop" class="callback-wrap el-hide"> 
    <div id="close_popup" class="close-popup el-hide"></div>   
    <?php echo do_shortcode ('[contact-form-7 id="24" title="Заказ обратного звонка"]');?>
</div>